package com.xoriant.locationapidemo.foursquare.model;

public class Icon {
    private  String prefix;
    private  String sufix;

    public String getPrefix() {
        return prefix;
    }

    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    public String getSufix() {
        return sufix;
    }

    public void setSufix(String sufix) {
        this.sufix = sufix;
    }

    @Override
    public String toString() {
        return "Icon{" +
                "prefix='" + prefix + '\'' +
                ", sufix='" + sufix + '\'' +
                '}';
    }
}
