package com.xoriant.locationapidemo.location.repository;

import com.xoriant.locationapidemo.location.entity.FavouritePlaceEntity;
import com.xoriant.locationapidemo.location.model.FavouritePlace;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Repository
public class FavouritePlaceRepository {

    private static final Logger LOGGER = LogManager.getLogger(FavouritePlaceRepository.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<FavouritePlaceEntity> getAllFavouritePlaces(String userId) {
        MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
        mapSqlParameterSource.addValue("userId", userId);
        List<FavouritePlaceEntity> favouritePlaceEntities = namedParameterJdbcTemplate.query(FavouritePlaceEntity.GET_ALL_FAVOURITE_PLACES, mapSqlParameterSource, new FavouritePlaceRowMapper());
        LOGGER.info("Favourite places for user " + userId + " :: " + favouritePlaceEntities);
        return favouritePlaceEntities;
    }

    public void addFavouritePlace(String userId, List<FavouritePlace> favouritePlaceList) {
        ArrayList<Object[]> list = new ArrayList<>();
        favouritePlaceList.forEach(favouritePlace -> list.add(new Object[]{userId, favouritePlace.getPlaceId()}));
        jdbcTemplate.batchUpdate(FavouritePlaceEntity.ADD_FAVOURITE_PLACES, list);
        LOGGER.info("Favourite places added successfully for user " + userId);
    }

    public void removeFavouritePlace(String userId, String placeId) {
        MapSqlParameterSource mapSqlParameterSource = new MapSqlParameterSource();
        mapSqlParameterSource.addValue("userId", userId);
        mapSqlParameterSource.addValue("placeId", placeId);
        namedParameterJdbcTemplate.update(FavouritePlaceEntity.REMOVE_FAVOURITE_PLACES, mapSqlParameterSource);
        LOGGER.info("Favourite places removed for user " + userId );
    }

    private class FavouritePlaceRowMapper implements RowMapper<FavouritePlaceEntity> {

        @Override
        public FavouritePlaceEntity mapRow(ResultSet resultSet, int i) throws SQLException {
            FavouritePlaceEntity entity = new FavouritePlaceEntity();
            entity.setPlaceId(resultSet.getString("place_id"));
            entity.setUserId(resultSet.getString("user_id"));
            return entity;
        }
    }
}
