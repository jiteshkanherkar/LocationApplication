package com.xoriant.locationapidemo.foursquare.model;

import java.util.List;

public class Body {
    private List<Venue> venues;
    private Venue venue;

    public List<Venue> getVenues() {
        return venues;
    }

    public void setVenues(List<Venue> venues) {
        this.venues = venues;
    }

    public Venue getVenue() {
        return venue;
    }

    public void setVenue(Venue venue) {
        this.venue = venue;
    }

    @Override
    public String toString() {
        return "Body{" +
                "venues=" + venues +
                ", venue=" + venue +
                '}';
    }
}
