package com.xoriant.locationapidemo.foursquare.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CategoryResponse {
    private MetaInfo meta;

    @JsonProperty("response")
    private CategoryBody body;

    public CategoryBody getBody() {
        return body;
    }

    public void setBody(CategoryBody body) {
        this.body = body;
    }

    public MetaInfo getMeta() {
        return meta;
    }

    public void setMeta(MetaInfo meta) {
        this.meta = meta;
    }

    @Override
    public String toString() {
        return "CategoryResponse{" +
                "meta=" + meta +
                ", body=" + body +
                '}';
    }


}
