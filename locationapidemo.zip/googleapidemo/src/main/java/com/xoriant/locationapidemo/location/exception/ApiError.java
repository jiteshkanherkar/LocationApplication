package com.xoriant.locationapidemo.location.exception;

import org.apache.http.client.utils.DateUtils;
import org.springframework.http.HttpStatus;

import java.util.Date;

public class ApiError {
    private HttpStatus status;
    private String timestamp;
    private String message;
    private String debugMessage;

    public ApiError() {
        this.timestamp= DateUtils.formatDate(new Date(),"dd-MM-yyyy hh:mm:ss");
    }

    public HttpStatus getStatus() {
        return status;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDebugMessage() {
        return debugMessage;
    }

    public void setDebugMessage(String debugMessage) {
        this.debugMessage = debugMessage;
    }
}
