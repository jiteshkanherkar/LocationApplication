package com.xoriant.locationapidemo.location.service;

import com.xoriant.locationapidemo.location.exception.CategoryNotFoundException;
import com.xoriant.locationapidemo.location.model.Category;

import java.util.List;

public interface ICategoryService {

    List<Category> getAllCategories() throws CategoryNotFoundException;
}
