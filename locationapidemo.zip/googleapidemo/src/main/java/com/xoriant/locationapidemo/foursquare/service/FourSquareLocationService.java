package com.xoriant.locationapidemo.foursquare.service;

import com.xoriant.locationapidemo.foursquare.LocationMapper;
import com.xoriant.locationapidemo.foursquare.model.LocationResponse;
import com.xoriant.locationapidemo.location.exception.LocationNotFoundException;
import com.xoriant.locationapidemo.location.model.LocationDetail;
import com.xoriant.locationapidemo.location.model.LocationSearchRequest;
import com.xoriant.locationapidemo.location.service.ILocationService;
import com.xoriant.locationapidemo.utils.CommonUtil;
import com.xoriant.locationapidemo.utils.HttpClientUtil;
import com.xoriant.locationapidemo.utils.JsonUtil;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.utils.DateUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Map;

@Service
public class FourSquareLocationService extends FourSquareService implements ILocationService {

    private static final Logger LOGGER = LogManager.getLogger(FourSquareLocationService.class);

    @Value("${client_id}")
    private String clientId;

    @Value("${client_secret}")
    private String clientSecret;

    @Value("${fourSquare_endPoint}")
    private String endPoint;

    @Autowired
    private CommonUtil commonUtil;

    @Autowired
    private HttpClientUtil httpClientUtil;

    @Autowired
    private JsonUtil jsonUtil;

    @Override
    public LocationDetail searchPlace(LocationSearchRequest locationSearchRequest) throws LocationNotFoundException{
        LOGGER.info("LocationSearch Request : "+locationSearchRequest);
        Map<String, String> params = initParams(clientId, clientSecret,DateUtils.formatDate(new Date(), "yyyyMMdd"), "browse");
        commonUtil.mapValuesFromObj(locationSearchRequest, params);
        LocationResponse locationResponse = execute(endPoint + "search?", params);
        LOGGER.info("Response : "+locationResponse);
        return LocationMapper.mapLocationDetail(locationResponse);
    }

    @Override
    public LocationDetail getPlaceDetails(String placeId)throws LocationNotFoundException {
        Map<String, String> params = initParams(clientId, clientSecret,DateUtils.formatDate(new Date(), "yyyyMMdd"), null);
        LocationResponse locationResponse = execute(endPoint + placeId + "?", params);
        LOGGER.info(locationResponse);
        return LocationMapper.mapPlaceDetail(locationResponse);
    }

    private LocationResponse execute(String requestUrl,Map<String, String> params) throws LocationNotFoundException{
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
            CloseableHttpResponse httpResponse = httpClient.execute(httpClientUtil.createHttpGetRequest(requestUrl, params));
            return convertResponseToObject(httpResponse);
        } catch (IOException e) {
            LOGGER.error("Exception in Location service",e);
            throw  new LocationNotFoundException("Exception in Location service");
        }
    }

    private LocationResponse convertResponseToObject(CloseableHttpResponse httpResponse) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(httpResponse.getEntity().getContent()))) {
            return jsonUtil.getObjectMapper().readValue(reader, LocationResponse.class);
        }
    }
}
