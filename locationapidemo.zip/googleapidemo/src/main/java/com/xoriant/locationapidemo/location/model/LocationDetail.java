package com.xoriant.locationapidemo.location.model;


import java.util.ArrayList;
import java.util.List;

public class LocationDetail {
    private List<Place> places;

    public List<Place> getPlaces() {
        if(places==null){
            places=new ArrayList<>();
        }
        return places;
    }

    public void setPlaces(List<Place> places) {
        this.places = places;
    }

    @Override
    public String toString() {
        return "LocationDetail{" +
                "places=" + places +
                '}';
    }
}
