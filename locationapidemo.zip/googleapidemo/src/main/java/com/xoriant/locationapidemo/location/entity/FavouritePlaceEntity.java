package com.xoriant.locationapidemo.location.entity;

public class FavouritePlaceEntity {
    private String userId;
    private String placeId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }

    @Override
    public String toString() {
        return "FavouritePlaceEntity{" +
                "userId='" + userId + '\'' +
                ", placeId='" + placeId + '\'' +
                '}';
    }

    public static final String GET_ALL_FAVOURITE_PLACES = "Select * from FAVOURITE_PLACES where user_id =:userId";
    public static final String ADD_FAVOURITE_PLACES = "insert into FAVOURITE_PLACES (user_id, place_id) values (?,?)";
    public static final String REMOVE_FAVOURITE_PLACES = "delete from FAVOURITE_PLACES where user_id =:userId and place_id=:placeId";
}
