package com.xoriant.locationapidemo.location.model;

public class FavouritePlace {
    private String placeId;

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId;
    }
}
