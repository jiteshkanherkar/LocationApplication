package com.xoriant.locationapidemo.google.service.impl;

import com.xoriant.locationapidemo.google.service.IGoogleILocationService;
import com.xoriant.locationapidemo.location.model.LocationDetail;
import com.xoriant.locationapidemo.location.model.LocationSearchRequest;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class GoogleLocationService implements IGoogleILocationService {

    @Value("${GOOGLE_API_ENDPOINT}")
    private String apiEndpoint="https://maps.googleapis.com/maps/api/place/findplacefromtext/json";

    @Value("${GOOGLE_API_KEY}")
    private String apiKey="AIzaSyAYt2c9cpTO-gplf7_d7WJOvnsRuf74klw";

    @Override
    public LocationDetail searchPlace(LocationSearchRequest locationSearchRequest) {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        HttpGet httpGet=new HttpGet();
        return null;
    }

    @Override
    public LocationDetail getPlaceDetails(String placeId) {
        return null;
    }


}
