package com.xoriant.locationapidemo.foursquare;

import com.xoriant.locationapidemo.foursquare.model.CategoryResponse;
import com.xoriant.locationapidemo.foursquare.model.LocationResponse;
import com.xoriant.locationapidemo.foursquare.model.Venue;
import com.xoriant.locationapidemo.location.exception.CategoryNotFoundException;
import com.xoriant.locationapidemo.location.exception.LocationNotFoundException;
import com.xoriant.locationapidemo.location.model.Category;
import com.xoriant.locationapidemo.location.model.LocationDetail;
import com.xoriant.locationapidemo.location.model.Place;

import java.util.ArrayList;
import java.util.List;

public class LocationMapper {
    public static LocationDetail mapLocationDetail(LocationResponse locationResponse) throws LocationNotFoundException {
        if(locationResponse==null ) return null;

        if(!locationResponse.getMeta().getCode().equals("200")){
            throw new LocationNotFoundException(locationResponse.getMeta().getErrorType()+"-"+locationResponse.getMeta().getErrorDetail());
        }

        List<Venue> venues = locationResponse.getBody().getVenues();

        List<Place> placeList=new ArrayList<>();
        venues.forEach((venue)->placeList.add(mapPlaceObject(venue)));
        LocationDetail locationDetail = new LocationDetail();
        locationDetail.setPlaces(placeList);

        return locationDetail;
    }
    public static LocationDetail mapPlaceDetail(LocationResponse locationResponse) throws LocationNotFoundException {
        if(locationResponse==null) return null;

        if(!locationResponse.getMeta().getCode().equals("200")){
            throw new LocationNotFoundException(locationResponse.getMeta().getErrorType()+"-"+locationResponse.getMeta().getErrorDetail());
        }

        Venue venue = locationResponse.getBody().getVenue();

        Place place =mapPlaceObject(venue);
        LocationDetail locationDetail = new LocationDetail();
        locationDetail.getPlaces().add(place);

        return locationDetail;
    }
    public static List<Category> mapCategoryResponse(CategoryResponse categoryResponse) throws CategoryNotFoundException {
        if(categoryResponse==null ) return null;
        if(!categoryResponse.getMeta().getCode().equals("200")){
            throw new CategoryNotFoundException(categoryResponse.getMeta().getErrorType()+"-"+categoryResponse.getMeta().getErrorDetail());
        }
        List<com.xoriant.locationapidemo.foursquare.model.Category> categoryList = categoryResponse.getBody().getCategories();
        return mapCategories(categoryList);
    }
    private static Place mapPlaceObject(Venue venue){
        Place place = new Place();
        place.setName(venue.getName());
        place.setPlaceId(venue.getId());
        place.setAddress(venue.getLocation().getAddressString().toString());
        place.setCategories(mapCategories(venue.getCategories()));
        return place;
    }

    private static List<Category> mapCategories(List<com.xoriant.locationapidemo.foursquare.model.Category> categories) {
        if(categories==null || categories.isEmpty()) return  null;
        List<Category> list=new ArrayList<>();
        categories.forEach((category)->list.add(mapCategory(category)));
        return  list;
    }

    private static Category mapCategory(com.xoriant.locationapidemo.foursquare.model.Category category) {
        Category _category =new Category();
        _category.setId(category.getId());
        _category.setName(category.getName());
        _category.setIcon(category.getIcon());
        _category.setCategories(mapCategories(category.getCategories()));
        return _category;
    }
}
