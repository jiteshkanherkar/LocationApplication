package com.xoriant.locationapidemo.foursquare.service;

import com.xoriant.locationapidemo.foursquare.LocationMapper;
import com.xoriant.locationapidemo.foursquare.model.CategoryResponse;
import com.xoriant.locationapidemo.location.exception.CategoryNotFoundException;
import com.xoriant.locationapidemo.location.model.Category;
import com.xoriant.locationapidemo.location.service.ICategoryService;
import com.xoriant.locationapidemo.utils.CommonUtil;
import com.xoriant.locationapidemo.utils.HttpClientUtil;
import com.xoriant.locationapidemo.utils.JsonUtil;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.utils.DateUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class FourSquareCategoryService extends FourSquareService implements ICategoryService {
    private  static final Logger LOGGER= LogManager.getLogger(FourSquareCategoryService.class);

    @Value("${client_id}")
    private String clientId;
    @Value("${client_secret}")
    private String clientSecret;
    @Value("${fourSquare_endPoint}")
    private String endPoint;

    @Autowired
    private CommonUtil commonUtil;

    @Autowired
    private HttpClientUtil httpClientUtil;

    @Autowired
    private JsonUtil jsonUtil;

    @Override
    public List<Category> getAllCategories() throws CategoryNotFoundException{
        Map<String, String> params = super.initParams(clientId, clientSecret, DateUtils.formatDate(new Date(), "yyyyMMdd"),null);
        try (CloseableHttpClient httpClient = HttpClientBuilder.create().build()) {
            CloseableHttpResponse httpResponse = httpClient.execute(httpClientUtil.createHttpGetRequest(endPoint+"categories?", params));
            CategoryResponse categoryResponse = convertResponseToObject(httpResponse);
            LOGGER.info("Category response : "+categoryResponse);
            return LocationMapper.mapCategoryResponse(categoryResponse);
        } catch (IOException e) {
           LOGGER.error("Exception in fetching all categories ",e);
            throw new CategoryNotFoundException("Exception in fetching categories");
        }
    }

    private CategoryResponse convertResponseToObject(CloseableHttpResponse httpResponse) throws IOException {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(httpResponse.getEntity().getContent()))) {
            return jsonUtil.getObjectMapper().readValue(reader, CategoryResponse.class);
        }
    }

}
