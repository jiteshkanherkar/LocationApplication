package com.xoriant.locationapidemo.location.service.impl;

import com.xoriant.locationapidemo.location.entity.FavouritePlaceEntity;
import com.xoriant.locationapidemo.location.model.FavouritePlace;
import com.xoriant.locationapidemo.location.repository.FavouritePlaceRepository;
import com.xoriant.locationapidemo.location.service.IManageFavouriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ManageFavouriteService implements IManageFavouriteService {

    @Autowired
    private FavouritePlaceRepository favouritePlaceRepository;

    @Override
    public List<FavouritePlaceEntity> getFavouritePlaceList(String userId) {
        return favouritePlaceRepository.getAllFavouritePlaces(userId);
    }

    @Override
    public void addFavouritePlace(String userId, List<FavouritePlace> favouritePlaceList) {
        favouritePlaceRepository.addFavouritePlace(userId, favouritePlaceList);
    }

    @Override
    public void removeFavouritePlace(String userId, String placeId) {
        favouritePlaceRepository.removeFavouritePlace(userId,placeId);
    }
}
