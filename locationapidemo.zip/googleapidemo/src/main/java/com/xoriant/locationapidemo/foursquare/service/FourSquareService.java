package com.xoriant.locationapidemo.foursquare.service;

import org.springframework.util.StringUtils;

import java.util.Map;
import java.util.TreeMap;

public abstract class FourSquareService {

    protected Map<String, String> initParams(String clientId, String clientSecret, String version, String intent) {
        Map<String, String> paramMap = new TreeMap<>();
        paramMap.put("client_id", clientId);
        paramMap.put("client_secret", clientSecret);
        paramMap.put("v", version);
        if (!StringUtils.isEmpty(intent)) paramMap.put("intent", intent);
        return paramMap;
    }


}
