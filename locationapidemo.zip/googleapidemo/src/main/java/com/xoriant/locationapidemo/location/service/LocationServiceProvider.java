package com.xoriant.locationapidemo.location.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LocationServiceProvider {

    @Autowired
    private ILocationService googleLocationService;

    @Autowired
    private ILocationService fourSquareLocationService;

    public ILocationService getLocationService(){
        return fourSquareLocationService;
    }
}
