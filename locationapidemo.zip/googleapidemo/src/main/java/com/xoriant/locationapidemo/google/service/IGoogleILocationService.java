package com.xoriant.locationapidemo.google.service;

import com.xoriant.locationapidemo.location.service.ILocationService;

public interface IGoogleILocationService extends ILocationService {

}
