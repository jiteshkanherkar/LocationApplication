package com.xoriant.locationapidemo.location.controller;

import com.xoriant.locationapidemo.location.exception.LocationNotFoundException;
import com.xoriant.locationapidemo.location.model.LocationDetail;
import com.xoriant.locationapidemo.location.model.LocationSearchRequest;
import com.xoriant.locationapidemo.location.service.ILocationService;
import com.xoriant.locationapidemo.location.service.LocationServiceProvider;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;

@RestController
@RequestMapping("/api/location")
@Api(value = "LocationSearchController to search diffrent places in the world ")
public class LocationController {

    @Autowired
    private LocationServiceProvider locationServiceProvider;
    private static final Logger LOGGER = LogManager.getLogger(LocationController.class);

    @GetMapping
    @ApiOperation(produces = "application/json", value = "Get all available location with given search criteria", response = LocationDetail.class)
    public ResponseEntity<?> searchPlaces(@RequestParam("query") @NotEmpty String query,
                                          @RequestParam("nearBy") @NotEmpty String near,
                                          @RequestParam(value = "limit", required = false) Integer limit,
                                          @RequestParam(value = "radius", required = false) Long radius) throws LocationNotFoundException {
        LOGGER.info("Location controller :: search places for " + query);
        ILocationService locationService = locationServiceProvider.getLocationService();
        LocationDetail locationDetail = locationService.searchPlace(new LocationSearchRequest(near, query, limit, radius));
        return ResponseEntity.ok(locationDetail);
    }


    @GetMapping("{locationId}")
    @ApiOperation(produces = "application/json", value = "Get selected location details including reviews, photos etc", response = LocationDetail.class)
    public ResponseEntity<?> getPlaceDetails(@PathVariable("locationId") String locationId) throws LocationNotFoundException{
        LOGGER.info("Location controller :: get place details for " + locationId);
        ILocationService locationService = locationServiceProvider.getLocationService();
        LocationDetail placeDetail = locationService.getPlaceDetails(locationId);
        return ResponseEntity.ok(placeDetail);
    }
}
