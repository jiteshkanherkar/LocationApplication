package com.xoriant.locationapidemo.location.model;

public class LocationSearchRequest {
    private String near;
    private String query;
    private Integer limit;
    private Long radius;

    public LocationSearchRequest() {
    }

    public LocationSearchRequest(String near, String query, Integer limit, Long radius) {
        this.near = near;
        this.query = query;
        this.limit = limit;
        this.radius = radius;
    }

    public String getNear() {
        return near;
    }

    public void setNear(String near) {
        this.near = near;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public Integer getLimit() {
        return limit;
    }

    public void setLimit(Integer limit) {
        this.limit = limit;
    }

    public Long getRadius() {
        return radius;
    }

    public void setRadius(Long radius) {
        this.radius = radius;
    }
}
