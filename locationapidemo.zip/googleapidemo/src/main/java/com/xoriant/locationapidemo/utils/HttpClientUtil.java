package com.xoriant.locationapidemo.utils;

import org.apache.http.client.methods.HttpGet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class HttpClientUtil {

    @Autowired
    private  CommonUtil commonUtil;

    public HttpGet createHttpGetRequest(String endPoint, Map<String,String> paramMap){
        HttpGet httpGet= new HttpGet(endPoint+commonUtil.convertMapToQueryString(paramMap,"&"));
        System.out.println(httpGet.toString());
        return httpGet;
    }


}
