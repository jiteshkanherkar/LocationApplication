package com.xoriant.locationapidemo.utils;

import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.Map;

@Component
public class CommonUtil {

    public <T> void mapValuesFromObj(T t, Map<String, String> paramMap) {
        Field[] declaredFields = t.getClass().getDeclaredFields();
        if (paramMap == null || t == null) return;
        try {
            for (Field field : declaredFields) {
                field.setAccessible(true);
                Object object = field.get(t);
                if (object != null) paramMap.put(field.getName(), object.toString());
            }
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public String convertMapToQueryString(Map<String, String> paramMap, String delimiter) {
        StringBuilder builder = new StringBuilder();
        paramMap.forEach((key, value) -> builder.append(key + "=" + value + delimiter));
        return builder.length() > 1 ? builder.toString().substring(0, builder.length() - 1) : builder.toString();
    }

}
