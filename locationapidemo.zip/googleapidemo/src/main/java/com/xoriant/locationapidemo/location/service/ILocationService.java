package com.xoriant.locationapidemo.location.service;

import com.xoriant.locationapidemo.location.exception.LocationNotFoundException;
import com.xoriant.locationapidemo.location.model.LocationDetail;
import com.xoriant.locationapidemo.location.model.LocationSearchRequest;

public interface ILocationService {

    LocationDetail searchPlace(LocationSearchRequest locationSearchRequest)throws LocationNotFoundException;
    LocationDetail  getPlaceDetails(String placeId)throws LocationNotFoundException;
}
