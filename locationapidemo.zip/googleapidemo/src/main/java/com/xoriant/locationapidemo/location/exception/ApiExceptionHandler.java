package com.xoriant.locationapidemo.location.exception;

import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class ApiExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(LocationNotFoundException.class)
    protected ResponseEntity<?> handleLocationNotFoundException(LocationNotFoundException ex){
        ApiError apiError = new ApiError();
        apiError.setStatus(HttpStatus.NOT_FOUND);
        apiError.setMessage("Unable to fetch location");
        apiError.setDebugMessage(ex.getMessage());
        return new ResponseEntity<>(apiError,apiError.getStatus());
    }

    @ExceptionHandler(CategoryNotFoundException.class)
    protected ResponseEntity<?> handleCategoryNotFoundException(CategoryNotFoundException ex){
        ApiError apiError = new ApiError();
        apiError.setStatus(HttpStatus.NOT_FOUND);
        apiError.setMessage("Unable to fetch categories");
        apiError.setDebugMessage(ex.getMessage());
        return new ResponseEntity<>(apiError,apiError.getStatus());
    }

    @ExceptionHandler(DataAccessException.class)
    protected ResponseEntity<?> handleDataAccessException(DataAccessException ex){
        ApiError apiError = new ApiError();
        apiError.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        apiError.setMessage("Internal server error");
        apiError.setDebugMessage(ex.getMessage());
        return new ResponseEntity<>(apiError,apiError.getStatus());
    }
}
