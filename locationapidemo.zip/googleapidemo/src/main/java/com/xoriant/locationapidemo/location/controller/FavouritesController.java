package com.xoriant.locationapidemo.location.controller;

import com.xoriant.locationapidemo.location.entity.FavouritePlaceEntity;
import com.xoriant.locationapidemo.location.model.FavouritePlace;
import com.xoriant.locationapidemo.location.service.IManageFavouriteService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/favourite")
public class FavouritesController {

    @Autowired
    private IManageFavouriteService manageFavouriteService;

    @GetMapping("{userId}")
    @ApiOperation(value = "Get all favourite place ids for given user from DB",
            produces = "application/json",
            response = FavouritePlaceEntity.class)
    public List<FavouritePlaceEntity> getFavouritePlaceList(@PathVariable("userId") String userId) {
        return manageFavouriteService.getFavouritePlaceList(userId);
    }

    @PostMapping("{userId}")
    @ApiOperation(value = "Add all place ids in favourite list of given user in DB",
            consumes = "application/json",
            code = 200)
    public void addFavouritePlace(@PathVariable("userId") String userId, @RequestBody List<FavouritePlace> favouritePlaceList) {
        manageFavouriteService.addFavouritePlace(userId, favouritePlaceList);
    }

    @DeleteMapping("{userId}")
    @ApiOperation(value = "remove place id from favourite list of given user",
            consumes = "application/json",
            code = 200)
    public void removeFavouritePlace(@PathVariable("userId") String userId, @RequestBody FavouritePlace favouritePlace) {
        manageFavouriteService.removeFavouritePlace(userId, favouritePlace.getPlaceId());
    }
}
