package com.xoriant.locationapidemo.location.controller;

import com.xoriant.locationapidemo.foursquare.model.CategoryResponse;
import com.xoriant.locationapidemo.location.exception.CategoryNotFoundException;
import com.xoriant.locationapidemo.location.model.Category;
import com.xoriant.locationapidemo.location.service.ICategoryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/category")
@Api(value = "Provide services for location search categories")
public class CategoryController {

    @Autowired
    ICategoryService categoryService;

    private static final Logger LOGGER = LogManager.getLogger(CategoryController.class);

    @GetMapping
    @ApiOperation(produces = "application/json", value = "get list of all avaible categories of location", response = CategoryResponse.class)
    public ResponseEntity<?> getAllCategories() throws CategoryNotFoundException {
        LOGGER.info("Fetch all categories available for search");
        List<Category> allCategories = categoryService.getAllCategories();
        return ResponseEntity.ok().body(allCategories);
    }
}
