package com.xoriant.locationapidemo.location.service;

import com.xoriant.locationapidemo.location.entity.FavouritePlaceEntity;
import com.xoriant.locationapidemo.location.model.FavouritePlace;

import java.util.List;

public interface IManageFavouriteService {

    List<FavouritePlaceEntity> getFavouritePlaceList(String userId);
    void addFavouritePlace(String userId, List<FavouritePlace> favouritePlaceList);
    void removeFavouritePlace(String userId, String placeId);
}
