package com.xoriant.locationapidemo.foursquare.model;

public class MetaInfo {
    private  String code;
    private  String errorType;
    private  String errorDetail;
    private  String requestId;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getErrorType() {
        return errorType;
    }

    public void setErrorType(String errorType) {
        this.errorType = errorType;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    public void setErrorDetail(String errorDetail) {
        this.errorDetail = errorDetail;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @Override
    public String toString() {
        return "MetaInfo{" +
                "code='" + code + '\'' +
                ", errorType='" + errorType + '\'' +
                ", errorDetail='" + errorDetail + '\'' +
                ", requestId='" + requestId + '\'' +
                '}';
    }
}
