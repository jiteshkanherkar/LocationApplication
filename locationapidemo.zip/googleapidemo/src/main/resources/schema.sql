create table favourite_places
(
   user_id varchar(255) not null,
   place_id varchar(255) not null,
);