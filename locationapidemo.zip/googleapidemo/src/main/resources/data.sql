insert into favourite_places
values('jitu', '5c74e490872f7d0039a394d3');

insert into favourite_places
values('jitu', '5b99026fc97f28002c751ada');