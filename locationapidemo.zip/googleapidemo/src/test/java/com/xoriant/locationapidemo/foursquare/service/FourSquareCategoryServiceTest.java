package com.xoriant.locationapidemo.foursquare.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.xoriant.locationapidemo.TestDataConfig;
import com.xoriant.locationapidemo.location.exception.CategoryNotFoundException;
import com.xoriant.locationapidemo.location.model.Category;
import com.xoriant.locationapidemo.location.service.ICategoryService;
import com.xoriant.locationapidemo.utils.JsonUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TestDataConfig.class)
public class FourSquareCategoryServiceTest {

    @Autowired
    private ICategoryService fourSquareCategoryService;

    @Autowired
    private JsonUtil jsonUtil;

    private List<Category> expectedCategories;

    @Before
    public void init() throws IOException {
        System.setProperty("app.log.dir","");
        InputStream stream = FourSquareCategoryServiceTest.class.getResourceAsStream("/FourSquareCategoryResponse.json");
        expectedCategories= jsonUtil.getObjectMapper().readValue(stream, new TypeReference<ArrayList<Category>>() { });
    }

    @Test
    public void testGetAllCategories() throws CategoryNotFoundException {
        List<Category> allCategories = fourSquareCategoryService.getAllCategories();
        Assert.assertTrue(!allCategories.isEmpty());
        Assert.assertTrue(allCategories.size()==expectedCategories.size());
    }

}
