package com.xoriant.locationapidemo.foursquare.service;

import com.xoriant.locationapidemo.TestDataConfig;
import com.xoriant.locationapidemo.location.exception.LocationNotFoundException;
import com.xoriant.locationapidemo.location.model.LocationDetail;
import com.xoriant.locationapidemo.location.model.LocationSearchRequest;
import com.xoriant.locationapidemo.location.model.Place;
import com.xoriant.locationapidemo.location.service.ILocationService;
import com.xoriant.locationapidemo.utils.JsonUtil;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.io.InputStream;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = TestDataConfig.class)
public class FourSquareLocationServiceTest {

    @Autowired
    private ILocationService fourSquareLocationService;

    private LocationSearchRequest locationSearchRequest;

    private LocationDetail expectedLocationDetail;
    @Autowired
    private JsonUtil jsonUtil;

    @Before
    public void init() throws IOException {
        System.setProperty("app.log.dir","");

        locationSearchRequest=new LocationSearchRequest();
        locationSearchRequest.setQuery("yewale");
        locationSearchRequest.setNear("pune");
        locationSearchRequest.setLimit(1);

        InputStream stream = FourSquareLocationServiceTest.class.getResourceAsStream("/LocationResponse.json");
        expectedLocationDetail = jsonUtil.getObjectMapper().readValue(stream,LocationDetail.class);
    }
    @Test
    public void testSearchPlace() throws LocationNotFoundException {
        LocationDetail locationDetail = fourSquareLocationService.searchPlace(locationSearchRequest);
        Assert.assertTrue(locationDetail.getPlaces().size()==expectedLocationDetail.getPlaces().size());
        Place place = locationDetail.getPlaces().get(0);
        Place expectedPlace = expectedLocationDetail.getPlaces().get(0);
        Assert.assertEquals(place.getPlaceId(),expectedPlace.getPlaceId());
        Assert.assertEquals(place.getName(),expectedPlace.getName());
//        Assert.assertEquals(place.getAddress(),expectedPlace.getAddress());
    }

    @Test(expected = LocationNotFoundException.class)
    public void testSearchPlaceForException() throws LocationNotFoundException {
        locationSearchRequest=new LocationSearchRequest();
        locationSearchRequest.setQuery("yewale");
        locationSearchRequest.setNear("123123adasdadsa");
        locationSearchRequest.setLimit(1);
        LocationDetail locationDetail = fourSquareLocationService.searchPlace(locationSearchRequest);
        Assert.assertTrue(locationDetail.getPlaces().isEmpty());
    }

    @Test
    public void testGetPlaceDetail() throws LocationNotFoundException {
        LocationDetail placeDetails = fourSquareLocationService.getPlaceDetails("5c74e490872f7d0039a394d3");
        Place place = placeDetails.getPlaces().get(0);
        Place expectedPlace = expectedLocationDetail.getPlaces().get(0);
        Assert.assertEquals(place.getPlaceId(),expectedPlace.getPlaceId());
        Assert.assertEquals(place.getName(),expectedPlace.getName());
//        Assert.assertEquals(place.getAddress(),expectedPlace.getAddress());
    }
}
