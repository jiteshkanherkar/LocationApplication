package com.xoriant.locationapidemo;

import com.xoriant.locationapidemo.foursquare.service.FourSquareCategoryService;
import com.xoriant.locationapidemo.foursquare.service.FourSquareLocationService;
import com.xoriant.locationapidemo.location.service.ICategoryService;
import com.xoriant.locationapidemo.location.service.ILocationService;
import com.xoriant.locationapidemo.utils.CommonUtil;
import com.xoriant.locationapidemo.utils.HttpClientUtil;
import com.xoriant.locationapidemo.utils.JsonUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

import java.util.Properties;

@Configuration
public class TestDataConfig {

    @Bean
    public static PropertySourcesPlaceholderConfigurer properties() throws Exception {
        final PropertySourcesPlaceholderConfigurer pspc = new PropertySourcesPlaceholderConfigurer();
        Properties properties = new Properties();

        properties.setProperty("fourSquare_endPoint", "https://api.foursquare.com/v2/venues/");
        properties.setProperty("client_id", "MKTU10GWYQKLDFP3EE13AHFPB1Q4IKNA5RM3RD4GWBFKKJW1");
        properties.setProperty("client_secret", "CXSXITP4PMRGLHFYF3RK2J44CMAFGL5IJPZFINEMEEOU2ROY");

        pspc.setProperties(properties);
        return pspc;
    }

    @Bean
    public HttpClientUtil getHttpClientUtil(){
      return   new HttpClientUtil();
    }

    @Bean
    public JsonUtil getJsonUtil(){
        return new JsonUtil();
    }

    @Bean
    public CommonUtil getCommonUtil(){
        return new CommonUtil();
    }

    @Bean
    public  ILocationService getFourSquareLocationService(){
        return new FourSquareLocationService();
    }

    @Bean
    public ICategoryService getFourSquareCategoryService(){
        return new FourSquareCategoryService();
    }
}
